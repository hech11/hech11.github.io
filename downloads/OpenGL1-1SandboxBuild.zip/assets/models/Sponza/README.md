Sponza
===================

A fixed version of the sponza obj model.
The original model was created by Frank Meinl.
More info:
http://graphics.cs.williams.edu/data/meshes/crytek-sponza-copyright.html